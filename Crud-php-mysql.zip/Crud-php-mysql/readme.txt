CRUD con PHP y MySQL

El programa permite visualizar los usuarios registrados con su respectivo id, nombre, apellido, email, contraseña y nombre de usuario.

El host debe ser local con XAMPP.